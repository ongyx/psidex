#!/usr/bin/env python3

"""

0000  00000 00000 0   0   0   00  0
00  0 00      0   00 00  0 0  00  0
00000 00000   0   0 0 0 00000 0 0 0
00       00   0   0   0 0   0 0  00
00    00000 00000 0   0 0   0 0  00
(psiman)

v0.2.0-alpha

The cli-wrapper for psilib, allowing use
from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman

"""

# Import functions from stdlib
import sys
from inspect import signature
from distutils.version import LooseVersion

# Import functions from psilib
from psilib.repo import add, set, rem, fetch, list
from psilib.package import install, remove, desc, search, upgrade
from psilib.misc import license
from psilib.utils import ansi
from psilib import __version__

# Check if current psilib is supported:
def checkpsi():
	# Get psilib version
	supported_ver = "3.1.0-alpha"
	libver = __version__
	# Check if version is supported
	isSupported = LooseVersion(supported_ver) == LooseVersion(libver)
	isDepreciated = LooseVersion(supported_ver) > LooseVersion(libver)
	isTooNew = LooseVersion(supported_ver) < LooseVersion(libver)
	if isSupported:
		pass
	elif isDepreciated:
		raise DeprecationWarning("psilib is too old! Try reinstalling psilib.")
	elif isTooNew:
		raise DeprecationWarning("psilib is too new! Have you updated psiman?")

checkpsi()

credits_txt = (
	"""
\u001b[36m
0000  00000 00000 0   0   0   00  0
00  0 00      0   00 00  0 0  00  0
00000 00000   0   0 0 0 00000 0 0 0
00       00   0   0   0 0   0 0  00
00    00000 00000 0   0 0   0 0  00
(psiman)
\u001b[34m
v0.2.0-alpha
\u001b[0m
The cli-wrapper for psilib, allowing use
from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman

The license is as follows:
	"""
)

# If there are no arguements, provide user help
def getParameters(args):
	if len(args) == 1:
		print(
			"\nusage: psiman (action) [options] <input>\n"
			"Type [psiman -h] for help.\n"
		)
		return None
	else:
		arg1_raw = (sys.argv[1])
		return(arg1_raw)
		
# Get first arguement from params
arg1 = getParameters(sys.argv)
argall = sys.argv

# Declare wrapper-specific variables.
err = ("""
E: Invalid/unknown command. Try again.
usage: psiman (action) [options] <input>
Type [psiman help] for help.
""")

invalid_cmd = (ansi(31) + err + ansi(0))

version = "0.2.0-alpha"

# Dictionary used to map functions.
func_dict = {
	"help": "help",
	"credits": "credits",
	"addrepo": "add",
	"setrepo": "set",
	"delrepo": "rem",
	"install": "install",
	"remove": "remove",
	"desc": "desc",
	"fetch": "fetch",
	"search": "search",
	"listrepo": "list",
	"upgrade": "upgrade"
}

# Help function. This is specific to the wrapper itself.
def help():
	print(
		f"\npsiman v{version}, a"
		f" json-based package manager"
	)
	print(
		"""
package install/removal:
	install     Install packages to local
	remove      Remove PACKAGE from local
	
package info query:
	search      Search for packages
	            Special sorters:
	            modules/scripts/stable/rolling/
	            repo/local
	desc        Print json file of PACKAGE.
	
repository maintenence:
	addrepo     Add URL of index.json to 
	            repolist.json.
	            Currently supports Google
	            Drive, Dropbox
	            and raw(direct) URLs to a
	            index.json file.
	listrepo    Print all repos in 
	            repolist.json
	            with numbered lines
	setrepo     Sets Nth repository url as
	            the main repository
	delrepo     Removes Nth repository from
	            repolist.json
	fetch       Fetch latest index file from
	            main repository.
	
miscellanious:
	init        Restores repo to defaults OR
	            deletes all packages(wip).
	help        Print out this message.
	credits     Print credits and license.
	
This psiman can bake (pi)es.
		"""
	)
	
def credits():
	print(credits_txt)
	print(license())
	
# Special function that pretty-prints input based on type.
def prettyprint(text):
	input_type = type(text)
	# Define supported types to print
	isString = (input_type is str)
	isNumber = (input_type is int or input_type is float)
	isBool = (input_type is bool)
	isDict = (input_type is dict)
	if isString:
		print(ansi(32), text, ansi(0))
	elif isNumber:
		print(ansi(32), str(text), ansi(0))
	elif isBool:
		if text:
			print(ansi(32, bold=True), "Sucess!", ansi(0))
		elif not text:
			print(ansi(31, bold=True), "Failure!", ansi(0))
	elif isDict:
		print("\n")
		for key, val in text.items():
			# Unpack if there is a nested dict
			if type(val) is dict:
				print(ansi(34, bold=True) + key + ":")
				for keyn, valn in val.items():
					print(
						ansi(32, bold=True),
						keyn,
						": ",
						ansi(0),
						ansi(36),
						valn,
						ansi(0),
						sep="")
			else:
				print(
					ansi(32, bold=True),
					key,
					": ",
					ansi(0),
					ansi(36),
					val,
					ansi(0),
					sep="")
		print("\n")
	else:
		# A list/tuple.
		try:
			print(ansi(32))
			for i in text:
				print(i)
			print(ansi(0))
		except TypeError:
			# None type?
			print(text)
			
# Define main function.
def main():
	# Try to get function name. If it fails, print a error message.
	try:
		cmd_name = func_dict[arg1]
	except KeyError:
		if len(sys.argv) == 1:
			pass
		elif sys.argv[1] == "pi":
			print("PHI is one H of a lot cooler than PI!")
		else:
			print(invalid_cmd)
	else:
		# Check if function requires args.
		# By default, sys.argv[2] will be
		# passed to the function.
		func = eval(cmd_name)
		sig = signature(func)
		paramCount = len(sig.parameters)
		if paramCount == 0:
			if func() is None:
				pass
			else:
				prettyprint(func())
		elif paramCount == 1:
			try:
				prettyprint(func(sys.argv[2]))
			except IndexError:
				print(ansi(31))
				print(
					f"E: action {cmd_name} requires input, i.e\n"
					f"psiman {arg1} <input>\n"
					"Type (psiman -h) for more info."
				)
				print(ansi(0))
				
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
	main()
