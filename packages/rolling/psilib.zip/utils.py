"""
------------------
***psilib.utils***
------------------
Utilities for psilib.
Might be useful for other programs(???)

P.S: Anything with a underscore ("_") is
a low-level utility that interfaces directly
with psilib or its config. Do NOT use them.
"""

"""
Check if string is a number.
Copied from [https://stackoverflow.com/q/354038].
"""
def is_number(str_w_num):
	try:
		float(str_w_num)
		return True
	except ValueError:
		return False
		
"""
Splits strings more precisely.
Copied from [https://stackoverflow.com/a/52008134].
"""
def split(strng, sep, pos):
	strng = strng.split(sep)
	return sep.join(strng[:pos]), sep.join(strng[pos:])
	
"""
ANSI Colours for printing (Because why not?)
Code can be 30-37. In order of colours, these are black, red, green, yellow,
blue, magnenta, cyan, and white.
After every colour print, print ansi(0) to clear colour attributes.
"""
def ansi(code_r, bold=""):
	ansi_base = "\033"
	code = str(code_r)
	if bold:
		ansi_code = ansi_base + "[" + code + ";1m"
		return ansi_code
	else:
		ansi_code = ansi_base + "[" + code + "m"
		return ansi_code
		
"""
Checks if url is a vaild platform (Github, Google Drive, Dropbox)
If so, return True and the direct url to index.json.
"""
def checkurl(url):
	# Import urllib
	import urllib.parse as urlparse
	# Split url to list.
	url_list = urlparse.urlsplit(url)
	wloc = url_list.netloc
	wpath = url_list.path
	# Check for supported websites.
	if wloc == "drive.google.com":
		url_base = "https://drive.google.com/uc?export=download&id="
		# Strip file id from path
		wlist = wpath.split("/")
		id = wlist[3]
		url_p = url_base + id
		return True, url_p
	elif wloc == "www.dropbox.com":
		# Strip file id from path
		wlist = wpath.split("/")
		id = wlist[2]
		url_p = "https://dl.dropbox.com/s/" + id + "/index.json?dl=1"
		return True, url_p
	elif wloc == "raw.githubusercontent.com":
		return True, url
	else:
		return False, None
		
"""
Dumps name and version to version.json
"""
def _dumpversion(package, semver):
	# Import os and json
	import os
	import json
	path = os.path.expanduser("~/Documents/.psicfg/json/versions.json")
	# Load json already in versions file
	f = open(path, "r")
	try:
		ver_d = json.load(f)
	except json.decoder.JSONDecodeError:
		# Make new dict
		d = {}
		d.update({package: semver})
		json_str = json.dumps(d, indent=4)
		# Write to file
		with open(path, "w") as f:
			f.write(json_str)
	else:
		# Update existing dict
		ver_d.update({package: semver})
		json_str = json.dumps(ver_d, indent=4)
		# Write to file
		with open(path, "w") as f:
			f.write(json_str)

"""
Retreive version of pkg from version.json
file
"""
def _loadversion(pkg):
	# Import os and json
	import os
	import json
	path = os.path.expanduser("~/Documents/.psicfg/json/versions.json")
	# Load json already in versions file
	f = open(path, "r")
	try:
		ver_d = json.load(f)
	except json.decoder.JSONDecodeError:
		return None
	else:
		# Try to get version of pkg
		try:
			version = ver_d[pkg]
		except KeyError:
			return None
		else:
			return version

"""
Detects if package.json file contains
muitiple packages at once
"""
def _chkjsonfile(url):
	import requests
	import json
	from .exceptions import NoInternet
	# Checks for <#PACKAGE_NAME> at end of url
	url_p = url.split("#")
	# download and get dict of script
	try:
		pkg_json = requests.get(url)
	except requests.exceptions.ConnectionError:
		raise NoInternet
	pkg_dict = pkg_json.json()
	# If it is a multi-package json file,
	# download and return (the script info)
	# as a dict
	if len(url_p) == 2:
		pkg_name = url_p[-1]
		return_dict = pkg_dict[pkg_name]
		return return_dict
	else:
		# The json file only contains one
		# script, so return the dict.
		return pkg_dict

"""
Get url from script.json.
Because there are two diffrent ways to define
versions for a package, this is needed.
"""
def _geturlfromjson(script_dict):
	from distutils.version import LooseVersion
	# Get package name
	package = script_dict["name"]
	try:
		pkg_versions = sorted(script_dict["releases"], key=LooseVersion)
	except TypeError:
		# Does not use the version number
		# as a seprate dict to store versions
		# so iterate over the list to find
		# latest version.
		pkg_versions = script_dict["releases"]
		# A empty dict to store versions
		ver_d = {}
		d_counter = 0
		for d in pkg_versions:
			try:
				ver_d.update({d["version"]: d_counter})
			except KeyError:
				# Does not contain a version
				d_counter += 1
				pass
			else:
				d_counter += 1
		# Check if ver_d is empty: this means
		# that there is no version avaliable.
		# Take the last url in the list.
		if not bool(ver_d):
			url = pkg_versions[-1]["url"]
			return [url, None]
		else:
			ver_list = sorted(ver_d.keys(), key=LooseVersion)
			# Get url with latest version
			pkg_latest_version = ver_list[0]
			pos = ver_d[pkg_latest_version]
			url = pkg_versions[pos]["url"]
			return [url, pkg_latest_version]
	else:
		# Newer system that uses the version
		# number as a dict to store the url.
		pkg_latest_version = pkg_versions[0]
		url = script_dict["releases"][pkg_latest_version]["url"]
		return [url, pkg_latest_version]

"""
Get the direct download link to a gist:
"""
def get_gist_dl(url):
	import re
	# Check if url is actually a gist
	match = re.match('http(s?)://gist.github.com/([0-9a-zA-Z]*)/([0-9a-f]*)', url)
	if match:
		spliturl = url.split("/")
		# Get username and gist id
		username = spliturl[3]
		id = spliturl[4]
		# Join together the final URL
		sep = "/"
		url_p = sep.join(["https://gist.githubusercontent.com", username, id, "raw"])
		return [True, url_p]
	else:
		return [False, None]

"""
Check if file object is a pyui
"""
def isPYUI(fileobj):
	import json
	jsonstr = fileobj.decode('utf-8')
	try:
		json.loads(jsonstr)
	except json.JSONDecodeError:
		return False
	else:
		return True

"""
---------------------------
***END SPECIAL FUNCTIONS***
---------------------------
"""
