"""
Contains functions to handle packages
(install, remove, and list packages).
Throws custom exceptions if not sucrssful
(see ./exceptions.py)
"""

# Get global variables and exceptions
# (config.py):
from .config import psicfg_path, script_store, site_packages
from .exceptions import NoInternet, PackageNoExists, PackageNotInRepo
from .exceptions import InvalidJSON, RepoNoExists, RepolistMissing
from .exceptions import VersionErrorMore, VersionErrorSame, SearchNotMatched

# Import modules (local)
from .utils import _dumpversion, _loadversion

# Import modules (stdlib)
import os
import json
import requests
import glob
from zipfile import ZipFile
from distutils.version import LooseVersion

"""
Installs packages from the main index to
the script path (psi.config.script_store).
Returns True if sucessful.
"""
def install(pkg_name):
	# Get rid of spaces in package name
	package = pkg_name.replace(" ", "")
	# Get json list of repo
	# Get download url from json listing
	jsonfile = psicfg_path + "/json/index.json"
	with open(jsonfile, 'r') as f:
		json_content = json.load(f)
	try:
		pkg_url = json_content["scripts"][package]["meta_url"]
	except KeyError:
		raise PackageNotInRepo
	else:
		try:
			pkg_infofile = requests.get(pkg_url, allow_redirects=True)
		except requests.exceptions.ConnectionError:
			raise NoInternet
		else:
			# Save package json info as file
			with open(psicfg_path + "/json/" + package + ".json", "wb") as f:
				f.write(pkg_infofile.content)
			if pkg_infofile:
				pkg_infofile_p = json.loads(pkg_infofile.content.decode("ascii"))
				# Get url from pkg json file
				pkg_versions = sorted(pkg_infofile_p["releases"], key=LooseVersion)
				# Get latest version of package (highest sorted version number)
				pkg_latest_version = pkg_versions[0]
				# Output package name and version into versions.json
				# if version is higher
				localVersion = _loadversion(package)
				while True:
					if localVersion is None:
						_dumpversion(package, pkg_latest_version)
						break
					elif localVersion < pkg_latest_version:
						_dumpversion(package, pkg_latest_version)
						break
					elif localVersion == pkg_latest_version:
						raise VersionErrorSame
					elif localVersion > pkg_latest_version:
						raise VersionErrorMore
					break

				try:
					url = pkg_infofile_p["releases"][pkg_latest_version]["url"]
				except KeyError:
					raise InvalidJSON("Package has no valid download url.")
				else:
					# Get package and save it.
					pkgfile = requests.get(url)
					if pkgfile:
						# Write download to temp folder.
						pkgfile_p = psicfg_path + "/tmp/" + package + ".zip"
						open(pkgfile_p, 'a').close()
						with open(pkgfile_p, "wb") as f:
							f.write(pkgfile.content)
						# Extract package to script folder
						zf = ZipFile(pkgfile_p, 'r')
						# If type is module, extract to site-packages(3)
						if pkg_infofile_p["type"] == "script":
							zf.extractall(path=script_store)
						elif pkg_infofile_p["type"] == "module":
							module_path = site_packages + "/" + package
							os.mkdir(module_path)
							zf.extractall(path=module_path)
						# Remove package to save space.
						os.remove(pkgfile_p)
						return True
					elif pkgfile.status_code == 404:
						raise NoInternet
			elif pkg_infofile.status_code == 404:
				raise NoInternet
				
"""
Removes packages in local.
Returns True if sucessful, false if there
was a error removing a existing package.
(Maybe a permissions error?)
"""
def remove(pkg_name):
	# Remove spaces.
	package = pkg_name.replace(" ", "")
	script_d = script_store + package + ".py"
	if os.path.exists(script_d):
		try:
			os.remove(script_d)
		except OSError:
			return False
		else:
			# Load versions.json
			with open(psicfg_path + "/json/versions.json", "r") as f:
				rem_d = json.load(f)
			
			# Remove the package version from
			# the loaded dict
			remver = rem_d.pop(pkg_name, None)
			json_str = json.dumps(rem_d, indent=4)
			
			# Save back to versions.json
			with open(psicfg_path + "/json/versions.json", "w") as f:
				f.write(json_str)
			return True
	else:
		raise PackageNoExists
		
"""
Get infomation metadata on a package.
Will return a dictionary of metadata on the
package.
"""
def desc(pkg_name):
	# Get rid of spaces in package name
	package = pkg_name.replace(" ", "")
	# Get json list of repo
	# Get download url from json listing
	jsonfile = psicfg_path + "/json/index.json"
	if os.path.isfile(jsonfile):
		with open(jsonfile, 'r') as f:
			json_content = json.load(f)
			try:
				pkg_url = json_content["scripts"][package]["meta_url"]
			except KeyError:
				raise PackageNoExists
			else:
				pkg_infofile = requests.get(pkg_url, allow_redirects=True)
				# Save package json info as file
				with open(psicfg_path + "/json/" + package + ".json", "wb") as f:
					f.write(pkg_infofile.content)
				if pkg_infofile:
					pkg_info = json.loads(pkg_infofile.content.decode("ascii"))
					# Get desc from pkg json file
					return pkg_info
				else:
					raise NoInternet
	else:
		raise RepolistMissing("index.json does not exist. Run psi.package.fetch()")
		
"""
Returns a list of packages depending on
search terms (i.e, all modules/scripts,
packages with a certain name, in stable/
rolling branch, etc.)
"""
def search(terms):
	# Check if search terms match special
	# modifiers
	
	isTypeSearch = terms == "modules" or terms == "scripts"
	isBranchSearch = terms == "rolling" or terms == "stable"
	isLocaleSearch = terms == "lcl" or terms == "repo"
	
	# Define return list
	return_list = []
	
	# Load index.json
	with open(psicfg_path + "/json/index.json", "r") as f:
		index_j = json.load(f)
		
	# Search for modules/scripts.
	if isTypeSearch:
		# Iterate over all package metadata in index.
		packages = index_j["scripts"]
		for pkg_name in packages.keys():
			package_info = packages[pkg_name]
			for key, val in package_info.items():
				if terms == "scripts" and val == "script":
					return_list.append(pkg_name)
				elif terms == "modules" and val == "module":
					return_list.append(pkg_name)
		return(return_list)

	elif isBranchSearch:
		# Iterate over all package metadata in index.
		packages = index_j["scripts"]
		for pkg_name in packages.keys():
			package_info = packages[pkg_name]
			for key, val in package_info.items():
				if terms == "stable" and val == "stable":
					return_list.append(pkg_name)
				elif terms == "rolling" and val == "rolling":
					return_list.append(pkg_name)
		return(return_list)
		
	elif isLocaleSearch:
		# List all packages in repo
		if terms == "repo":
			# Get json file containing list of all packages in repo folder
			jsonfile = psicfg_path + '/json/index.json'
			getrepo_r = open(psicfg_path + '/repo/repolist.json', 'r')
			getrepo_f = json.load(getrepo_r)
			url = getrepo_f["mainrepo"]
			# Actual downloading and getting dictonary out of serialized json.
			try:
				json_content_r = requests.get(url)
			except requests.exceptions.ConnectionError:
				raise NoInternet
			else:
				json_content = json_content_r.json()
				url_stat = json_content_r.status_code
				if json_content:
					# If URL is valid, grab json listing of repo and cache it.
					with open(jsonfile, "w") as f_w:
						json.dump(json_content, f_w)
					# Read the dictionary and use to get package names.
					# Tries to read all values with key 'name' until IndexError.
					try:
						for key in json_content["scripts"]:
							return_list.append(key)
					except KeyError:
						raise RepoNoExists
					else:
						return_list.sort(key=str.lower)
						return return_list
				# If url returned 404, tell user to use another repo.
				elif url_stat == 404:
					raise NoInternet
		# List all packages in local
		elif terms == "lcl":
			# List all files with extention .py:
			filenme = [f for f in glob.glob(script_store + "*.py")]
			filenme.sort(key=str.lower)
			for x in filenme:
				if x.endswith(".py"):
					x_r = x.replace(script_store, "")
					x_p = x_r.replace(".py", "")
					return_list.append(x_p)
			return return_list
		
	else:
		# Search for terms within package names
		packages = index_j["scripts"]
		# If terms is only one letter long,
		# search for all packages starting
		# with that letter
		if len(terms) == 1:
			for pkg_name in packages.keys():
				if pkg_name.startswith(terms):
					return_list.append(pkg_name)
		else:
			for pkg_name in packages.keys():
				if terms in pkg_name:
					return_list.append(pkg_name)
		if len(return_list) == 0:
			raise SearchNotMatched
		else:
			return(return_list)

"""
(Bulk) upgrades all packages with a newer version
in the repository.
Returns a count of upgraded and not upgraded
packages.
"""
def upgrade():
	# Iterate though all installed packages
	# (in versions.json).
	notUpgraded_counter = 0
	upgraded_counter = 0
	with open(psicfg_path + "/json/versions.json", "r") as f:
		version_d = json.load(f)
	for pkg in version_d:
		try:
			install(pkg)
		except VersionErrorSame:
			notUpgraded_counter += 1
		else:
			upgraded_counter += 1
	return_dict = {}
	return_dict["upgraded"] = upgraded_counter
	return_dict["notupgraded"] = notUpgraded_counter
	return return_dict
