"""
Setups vendor (i.e, external) dependencies
for psiman. Also makes them importable.
"""
from . import semver
