#!/usr/bin/env python3

"""
┌─┐┌─┐┬┬  ┬┌┐
├─┘└─┐││  │├┴┐
┴  └─┘┴┴─┘┴└─┘
(psilib)
The Pythonista Script Index MANager (psiman)
in package form.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.
To print out the license, execute the below:
import psilib as psi; psi.misc.license()

Source:
https://github.com/sn3ksoftware/psiman
"""

name = "psilib"
__author__ = "Ong Yong Xin"
__version__ = "3.3.0-alpha"

# Import local utils and psi functions.

from . import misc
from . import utils
from . import repo
from . import package
from . import config

# Import external dependencies

from . import external
