"""
Contains functions to handle repos
(add, delete, set mainrepo).
Will throw custom exceptions if not
sucessful (see ./exceptions.py)
"""

# Get global variables and exceptions
# (config.py):
from .config import psicfg_path
from .exceptions import NullInput, RepolistMissing, NoInternet

# Import modules (local)
from .utils import is_number, checkurl

# Import modules (stdlib)
import json
import requests

"""
Adds repos to repolist.
Returns True if sucessful.
"""
def add(repourl):
	result = checkurl(repourl)
	if result[0]:
		try:
			repolist_f = open(psicfg_path + "/repo/repolist.json", "r")
		except IOError:
			raise RepolistMissing
		else:
			repolist_json = json.load(repolist_f)
			mainrepo_j = repolist_json["mainrepo"]
			repolist_p = repolist_json["repolist"]
			repolist_p.append(result[1])
			# Build dictionary to serialize into json
			# Just adds to current list of repos.
			repodict = dict({"mainrepo": mainrepo_j, "repolist": repolist_p})
			repolist_f = open(psicfg_path + "/repo/repolist.json", "w")
			json.dump(repodict, repolist_f)
			return True
	else:
		raise NullInput
		
"""
Sets the repository to pull packages from.
This is a interactive command.
"""
def set(mainrepo_c_raw):
	try:
		repolist_f = open(psicfg_path + '/repo/repolist.json', 'r')
	except IOError:
		raise RepolistMissing
	else:
		repolist_json = json.load(repolist_f)
		repolist_p = repolist_json["repolist"]
		# Check if input is actually a number
		if not is_number(mainrepo_c_raw):
			raise NullInput
		else:
			# Derive interger from input.
			mainrepo_c = int(float(mainrepo_c_raw))
			# Get line count for repolist.
			lineCount = len(repolist_p)
			# Check for invalid input.
			# (i.e, line 0)
			if mainrepo_c == "0":
				raise NullInput
			elif mainrepo_c > lineCount:
				raise NullInput
			else:
				# Get repo url.
				# Get choice minus 1 because list counting starts at 0
				mainrepo_c = mainrepo_c - 1
				mainrepo_curl = repolist_p[mainrepo_c]
				mainrepo_dict = dict({"mainrepo": mainrepo_curl, "repolist": repolist_p})
				with open(psicfg_path + '/repo/repolist.json', 'w') as f:
					json.dump(mainrepo_dict, f)
				return True
				
"""
Deletes a specific repository.
Also note that this is also interactive.
"""
def rem(delrepo_c_raw):
	try:
		repolist_f = open(psicfg_path + '/repo/repolist.json', 'r')
	except IOError:
		raise RepolistMissing
	else:
		repolist_json = json.load(repolist_f)
		repolist_p = repolist_json["repolist"]
		repolist_m = repolist_json["mainrepo"]
		# Check if input is actually a number
		if not is_number(delrepo_c_raw):
			raise NullInput
		else:
			# Derive interger from input.
			delrepo_c = int(float(delrepo_c_raw))
			# Get line count for repolist.
			lineCount = len(repolist_p)
			# Check for invalid input.
			# (i.e, line 0)
			if delrepo_c == "0":
				raise NullInput
			elif delrepo_c > lineCount:
				raise NullInput
			else:
				# Get choice minus 1 because list counting starts at 0
				delrepo_c = delrepo_c - 1
				# Delete url chosen and write back to json file
				del repolist_p[delrepo_c]
				delrepo_dict = dict({"mainrepo": repolist_m, "repolist": repolist_p})
				with open(psicfg_path + '/repo/repolist.json', 'w') as f:
					json.dump(delrepo_dict, f)
				return True

"""
Fetches the latest index.json file from the
mainrepo.
Returns True if sucessful.
"""
def fetch():
	jsonfile = psicfg_path + '/json/index.json'
	getrepo_r = open(psicfg_path + '/repo/repolist.json', 'r')
	getrepo_f = json.load(getrepo_r)
	url = getrepo_f["mainrepo"]
	# Actual downloading and getting dictonary out of serialized json.
	try:
		json_content_r = requests.get(url)
	except requests.exceptions.ConnectionError:
		raise NoInternet
	else:
		if json_content_r:
			json_content = json_content_r.content
			# Write fetched index to index.json
			with open(jsonfile, "wb") as f:
				f.write(json_content)
			return True
		else:
			raise NoInternet

"""
Print repos in repolist.json with numbered lines.
"""
def list():
	repo_list = {}
	# Try to get repolist.json
	try:
		repolist_f = open(psicfg_path + '/repo/repolist.json', 'r')
	except IOError:
		raise RepolistMissing
	else:
		repolist_json = json.load(repolist_f)
		repolist_p = repolist_json["repolist"]
		repo_counter = 1
		for i in repolist_p:
			counter_str = str(repo_counter)
			repo_list.update({counter_str: i})
			repo_counter += 1
		return repo_list
