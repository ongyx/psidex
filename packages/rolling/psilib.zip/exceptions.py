"""
Declare global exceptions for psimodule.
"""
class NoInternet(Exception):
	def __init__(self):
		Exception.__init__(self, "Server refused connection. Check internet?")
		
class NullInput(Exception):
	def __init__(self):
		Exception.__init__(self, "Invalid input.")
		
class RepolistMissing(Exception):
	def __init__(self):
		Exception.__init__(self, "Repolist not found. Does it exist?")
		
class PackageNoExists(Exception):
	def __init__(self):
		Exception.__init__(self, "Package does not exist!")
		
class PackageNotInRepo(Exception):
	def __init__(self):
		Exception.__init__(self, "Package not found in repo.")
		
class InvalidJSON(Exception):
	def __init__(self):
		Exception.__init__(self, "JSON file is not set properly!")
		
class RepoNoExists(Exception):
	def __init__(self):
		Exception.__init__(self, "Repository does not exist.")

class VersionErrorMore(Exception):
	def __init__(self):
		Exception.__init__(self,
		"""
		Package in repo is older than local.
		Are you using an outdated branch/repo?
		"""
		)

class VersionErrorSame(Exception):
	def __init__(self):
		Exception.__init__(self, "Package is same version. Not re-downloading.")

class SearchNotMatched(Exception):
	def __init__(self):
		Exception.__init__(self, "Your search did not match anything.")
