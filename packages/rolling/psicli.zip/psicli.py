#!/usr/bin/env python3

"""

0000  00000 00000 00000 0     00000
00  0 00      0   0     0       0
00000 00000   0   0     0       0
00       00   0   0     0       0
00    00000 00000 00000 00000 00000
(psicli)

v0.3.0-alpha

The command-line interface for psilib,
allowing use from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman

"""

# Import functions from stdlib
import sys
from inspect import signature
from distutils.version import LooseVersion

# Import functions from psilib
from psilib.repo import add, rem, fetch, list, update
from psilib.package import install, remove, desc, search, upgrade
from psilib.misc import license
from psilib.utils import ansi
from psilib.exceptions import *
from psilib import __version__


# Check if current psilib is supported:
def checkpsi():
	# Get psilib version
	supported_ver = "3.3.0-alpha"
	libver = __version__
	# Check if version is supported
	isSupported = LooseVersion(supported_ver) == LooseVersion(libver)
	isDepreciated = LooseVersion(supported_ver) > LooseVersion(libver)
	isTooNew = LooseVersion(supported_ver) < LooseVersion(libver)
	if isSupported:
		pass
	elif isDepreciated:
		raise DeprecationWarning("psilib is too old! Try reinstalling psilib.")
	elif isTooNew:
		raise DeprecationWarning("psilib is too new! Have you updated psicli?")

checkpsi()

credits_txt = (
	"""
\u001b[36m
0000  00000 00000 00000 0     00000
00  0 00      0   0     0       0
00000 00000   0   0     0       0
00       00   0   0     0       0
00    00000 00000 00000 00000 00000
(psicli)
\u001b[34m
v0.3.0-alpha
\u001b[0m
The command-line interface for psilib,
allowing use from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman
	"""
)

version = "0.2.1-alpha"


# Get script name
def getname():
	script_name = sys.argv[0].split("/")
	# Take the last item if sys.argv[0] is a path
	name = script_name[-1].replace(".py", "")
	return name

name = getname()


# If there are no arguements, provide user help
def getParameters(args):
	if len(args) == 1:
		print(
			f"\nusage: {name} (action) [options] <input>\n"
			f"Type [{name} help] for help.\n"
		)
		return None
	else:
		arg1_raw = (sys.argv[1])
		return(arg1_raw)
		
# Get first arguement from params
arg1 = getParameters(sys.argv)
argall = sys.argv

# Declare wrapper-specific variables.
err = ("""
E: Invalid/unknown command. Try again.
usage: psicli (action) [options] <input>
Type [psicli help] for help.
""")

invalid_cmd = (ansi(31) + err + ansi(0))

# Dictionary used to map functions.
func_dict = {
	"help": "help",
	"credits": "credits",
	"addrepo": "_add",
	"delrepo": "_rem",
	"install": "_install",
	"remove": "_remove",
	"desc": "_desc",
	"fetch": "fetch",
	"search": "_search",
	"upgrade": "upgrade",
	"update": "_update"
}


# Help function. This is specific to the wrapper itself.
def help():
	print(
		f"\n{name} v{version}, a json-based package manager"
		f"\n\nRunning on psilib v{__version__}."
	)
	print(
		"""
package install/removal:
	install     Install packages to local
	remove      Remove PACKAGE from local
	
package info query:
	search      Search for packages
	            Special sorters:
	            modules/scripts/stable
	            rolling/repo/local
	desc        Print json file of PACKAGE.
	
repository maintenence:
	addrepo     Add URL of index.json to
	            repolist.json.
	            Currently supports Google
	            Drive, Dropbox
	            and direct Github URLs to a
	            index.json file
	            (i.e, raw.githubusercontent.com)
	delrepo     Removes a repository from the
	            repolist
	update      Downloads latest index file
	            from mainrepo.
	fetch       Download a package without
	            installing it to current dir
	            (TODO)
	
miscellanious:
	init        Restores repo to defaults OR
	            deletes all packages(wip).
	help        Print out this message.
	credits     Print credits and license.
	
This psicli can bake (pi)es.
		"""
	)


def credits():
	print(credits_txt)
	print(license())


# Special function that pretty-prints input based on type.
def prettyprint(text):
	input_type = type(text)
	# Define supported types to print
	isString = (input_type is str)
	isNumber = (input_type is int or input_type is float)
	isBool = (input_type is bool)
	isDict = (input_type is dict)
	if isString:
		print(ansi(32), text, ansi(0))
	elif isNumber:
		print(ansi(32), str(text), ansi(0))
	elif isBool:
		if text:
			print(ansi(32, bold=True), "Sucess!", ansi(0))
		elif not text:
			print(ansi(31, bold=True), "Failure!", ansi(0))
	elif isDict:
		print("\n")
		for key, val in text.items():
			if key == "releases":
				if type(val) is dict:
					# Unpack dictionary
					print(ansi(34, bold=True) + key + ":\n")
					for keyn, valn in val.items():
						print(ansi(32, bold=True) + keyn + ":")
						for keynn, valnn in valn.items():
							print(
								ansi(32, bold=True),
								keynn,
								": ",
								ansi(0),
								ansi(36),
								valnn,
								ansi(0),
								sep="")
				else:
					# Unpack from list first
					print(ansi(34, bold=True) + key + ":\n")
					for i in val:
						for keyn, valn in i.items():
							print(
								ansi(32, bold=True),
								keyn,
								": ",
								ansi(0),
								ansi(36),
								valn,
								ansi(0),
								sep="")

			else:
				print(
					ansi(32, bold=True),
					key,
					": ",
					ansi(0),
					ansi(36),
					val,
					ansi(0),
					sep="")
		print("\n")
	else:
		# A list/tuple.
		try:
			print(ansi(32))
			for i in text:
				print(i)
			print(ansi(0))
		except TypeError:
			# None type?
			if text is None:
				pass
			else:
				print(text)

# WRAPPER FUNCTIONS
# Better-formatted output for functions.


def _install(pkg):
	print("\nInstalling", pkg, "...\n")
	try:
		return install(pkg)
	except PackageNotInRepo:
		print(ansi(31))
		print(f"E: Package is not in main repo.\nTry running [{name} update]?")
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except InvalidJSON:
		print(ansi(31))
		print(
			"E: The package JSON file is invalid."
			"Please contact the maintainers."
			)
	except VersionErrorSame:
		print(ansi(31))
		print("W: Package is same version as in repo.\nNot redownloading.")
	except VersionErrorMore:
		print(ansi(31))
		print("E: Local package version is newer than the version in the repo.")
		print("(Are you using a outdated repository?)")


def _remove(pkg):
	print("Removing", pkg, "...\n")
	try:
		result = remove(pkg)
	except PackageNoExists:
		print(ansi(31))
		print("E: Package does not exists in local. Try re-typing the package name.")
	else:
		if result["removed_package_version"]:
			prettyprint(True)
			print("Removed package from version.json.")
		else:
			prettyprint(False)
			print("E: Could not remove package from version.json.")
		
		__ = result.pop("removed_package_version", None)
		
		print("\nRemoved files:")
		prettyprint(result)


def _desc(pkg):
	try:
		return desc(pkg)
	except PackageNoExists:
		print(ansi(31))
		print(f"E: Package is not in main repo.\nTry running [{name} fetch]?")
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")


def _search(pkg):
	try:
		return search(pkg)
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except RepoNoExists:
		print(ansi(31))
		print("E: Repo does not exist!\nIs the URL valid?")
	except SearchNotMatched:
		print(ansi(31))
		print("E: Your search did not match anything. Try again?")


def _add(repo):
	print("\nAdding", repo, "...\n")
	try:
		return add(repo)
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")
	except NullInput:
		print(ansi(31))
		print("E: Invalid input.")


def _update():
	try:
		return update()
	except NoInternet:
		print(ansi(31))
		print("E: No Internet.\nCheck your internet connection?")


def _rem():
	print("\nHere is a list of all the repos:")
	prettyprint(list())
	choice = input("Select the repository to be deleted:\n>>> ")
	try:
		return rem(choice)
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")
	except NullInput:
		print(ansi(31))
		print("E: Invalid input.")


# Define main function.
def main():
	# Try to get function name. If it fails, print a error message.
	try:
		cmd_name = func_dict[arg1]
	except KeyError:
		if len(sys.argv) == 1:
			pass
		elif sys.argv[1] == "pi":
			print("PHI is one H of a lot cooler than PI!")
		else:
			print(invalid_cmd)
	else:
		# Check if function requires args.
		# By default, sys.argv[2] will be
		# passed to the function.
		func = eval(cmd_name)
		sig = signature(func)
		paramCount = len(sig.parameters)
		if paramCount == 0:
			prettyprint(func())
		elif paramCount == 1:
			try:
				prettyprint(func(sys.argv[2]))
			except IndexError:
				# Clean up underscores from name
				cmd_name_p = cmd_name.replace("_", "")
				print(ansi(31))
				print(
					f"E: action {cmd_name_p} requires input, i.e\n"
					f"{name} {arg1} <input>\n"
					f"Type [{name} -h] for more info."
				)
				print(ansi(0))
				
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
	main()
