#!/usr/bin/env python3

"""

0000  00000 00000 0   0   0   00  0
00  0 00      0   00 00  0 0  00  0
00000 00000   0   0 0 0 00000 0 0 0
00       00   0   0   0 0   0 0  00
00    00000 00000 0   0 0   0 0  00
(psiman)

v0.2.1-alpha

The cli-wrapper for psilib, allowing use
from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman

"""

# Import functions from stdlib
import sys
from inspect import signature
from distutils.version import LooseVersion

# Import functions from psilib
from psilib.repo import add, set, rem, fetch, list
from psilib.package import install, remove, desc, search, upgrade
from psilib.misc import license
from psilib.utils import ansi
from psilib.exceptions import *
from psilib import __version__

# Check if current psilib is supported:
def checkpsi():
	# Get psilib version
	supported_ver = "3.2.0-alpha"
	libver = __version__
	# Check if version is supported
	isSupported = LooseVersion(supported_ver) == LooseVersion(libver)
	isDepreciated = LooseVersion(supported_ver) > LooseVersion(libver)
	isTooNew = LooseVersion(supported_ver) < LooseVersion(libver)
	if isSupported:
		pass
	elif isDepreciated:
		raise DeprecationWarning("psilib is too old! Try reinstalling psilib.")
	elif isTooNew:
		raise DeprecationWarning("psilib is too new! Have you updated psiman?")

checkpsi()

credits_txt = (
	"""
\u001b[36m
0000  00000 00000 0   0   0   00  0
00  0 00      0   00 00  0 0  00  0
00000 00000   0   0 0 0 00000 0 0 0
00       00   0   0   0 0   0 0  00
00    00000 00000 0   0 0   0 0  00
(psiman)
\u001b[34m
v0.2.1-alpha
\u001b[0m
The cli-wrapper for psilib, allowing use
from the command-line.

Copyright (c) 2019 Ong Yong Xin
Open-sourced under the MIT License.

Source:
https://github.com/sn3ksoftware/psiman

The license is as follows:
	"""
)

# If there are no arguements, provide user help
def getParameters(args):
	if len(args) == 1:
		print(
			"\nusage: psiman (action) [options] <input>\n"
			"Type [psiman help] for help.\n"
		)
		return None
	else:
		arg1_raw = (sys.argv[1])
		return(arg1_raw)
		
# Get first arguement from params
arg1 = getParameters(sys.argv)
argall = sys.argv

# Declare wrapper-specific variables.
err = ("""
E: Invalid/unknown command. Try again.
usage: psiman (action) [options] <input>
Type [psiman help] for help.
""")

invalid_cmd = (ansi(31) + err + ansi(0))

version = "0.2.1-alpha"

# Dictionary used to map functions.
func_dict = {
	"help": "help",
	"credits": "credits",
	"addrepo": "_add",
	"setrepo": "_set",
	"delrepo": "_rem",
	"install": "_install",
	"remove": "_remove",
	"desc": "_desc",
	"fetch": "fetch",
	"search": "_search",
	"upgrade": "upgrade"
}

# Help function. This is specific to the wrapper itself.
def help():
	print(
		f"\npsiman v{version}, a"
		f" json-based package manager"
	)
	print(
		"""
package install/removal:
	install     Install packages to local
	remove      Remove PACKAGE from local
	
package info query:
	search      Search for packages
	            Special sorters:
	            modules/scripts/stable
	            rolling/repo/local
	desc        Print json file of PACKAGE.
	
repository maintenence:
	addrepo     Add URL of index.json to 
	            repolist.json.
	            Currently supports Google
	            Drive, Dropbox
	            and direct Github URLs to a
	            index.json file
	            (i.e, raw.githubusercontent.com)
	setrepo     Sets the main repository to
	            retrieve packages from
	delrepo     Removes a repository from the
	            repolist
	fetch       Fetch latest index file from
	            main repository.
	
miscellanious:
	init        Restores repo to defaults OR
	            deletes all packages(wip).
	help        Print out this message.
	credits     Print credits and license.
	
This psiman can bake (pi)es.
		"""
	)
	
def credits():
	print(credits_txt)
	print(license())
	
# Special function that pretty-prints input based on type.
def prettyprint(text):
	input_type = type(text)
	# Define supported types to print
	isString = (input_type is str)
	isNumber = (input_type is int or input_type is float)
	isBool = (input_type is bool)
	isDict = (input_type is dict)
	if isString:
		print(ansi(32), text, ansi(0))
	elif isNumber:
		print(ansi(32), str(text), ansi(0))
	elif isBool:
		if text:
			print(ansi(32, bold=True), "Sucess!", ansi(0))
		elif not text:
			print(ansi(31, bold=True), "Failure!", ansi(0))
	elif isDict:
		print("\n")
		for key, val in text.items():
			# Unpack if there is a nested dict
			if type(val) is dict:
				print(ansi(34, bold=True) + key + ":")
				for keyn, valn in val.items():
					print(
						ansi(32, bold=True),
						keyn,
						": ",
						ansi(0),
						ansi(36),
						valn,
						ansi(0),
						sep="")
			else:
				print(
					ansi(32, bold=True),
					key,
					": ",
					ansi(0),
					ansi(36),
					val,
					ansi(0),
					sep="")
		print("\n")
	else:
		# A list/tuple.
		try:
			print(ansi(32))
			for i in text:
				print(i)
			print(ansi(0))
		except TypeError:
			# None type?
			if text == None:
				pass
			else:
				print(text)

# WRAPPER FUNCTIONS
# Better-formatted output for functions.

def _install(pkg):
	print("\nInstalling", pkg, "...\n")
	try:
		return install(pkg)
	except PackageNotInRepo:
		print(ansi(31))
		print("E: Package is not in main repo.\nTry running [psiman fetch]?")
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except InvalidJSON:
		print(ansi(31))
		print("E: The package JSON file is invalid.\nPlease contact the maintainers.")
	except VersionErrorSame:
		print(ansi(31))
		print("W: Package is same version as in repo.\nNot redownloading.")
	except VersionErrorMore:
		print(ansi(31))
		print("E: Local package version is newer than the version in the repo.")
		print("(Are you using a outdated repository?)")

def _remove(pkg):
	print("Removing", pkg, "...\n")
	try:
		return remove(pkg)
	except PackageNoExists:
		print(ansi(31))
		print("E: Package does not exists in local. Try re-typing the package name.")

def _desc(pkg):
	try:
		return desc(pkg)
	except PackageNoExists:
		print(ansi(31))
		print("E: Package is not in main repo.\nTry running [psiman fetch]?")
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")

def _search(pkg):
	try:
		return search(pkg)
	except NoInternet:
		print(ansi(31))
		print("E: No internet.\nCheck your internet connection?")
	except RepoNoExists:
		print(ansi(31))
		print("E: Repo does not exist!\nIs the URL valid?")
	except SearchNotMatched:
		print(ansi(31))
		print("E: Your search did not match anything. Try again?")

def _add(repo):
	print("\nAdding", repo, "...\n")
	try:
		return add(repo)
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")
	except NullInput:
		print(ansi(31))
		print("E: Invalid input.")

def _fetch():
	try:
		return fetch()
	except NoInternet:
		print(ansi(31))
		print("E: No Internet.\nCheck your internet connection?")

def _set():
	print("\nHere is a list of all the repos:")
	prettyprint(list())
	choice = input("Select the repository to be used as the main:\n>>> ")
	try:
		return set(choice)
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")
	except NullInput:
		print(ansi(31))
		print("E: Invalid input.")

def _rem():
	print("\nHere is a list of all the repos:")
	prettyprint(list())
	choice = input("Select the repository to be deleted:\n>>> ")
	try:
		return rem(choice)
	except RepolistMissing:
		print(ansi(31))
		print("E: Repolist is missing.\n(Is your config set up properly?)")
	except NullInput:
		print(ansi(31))
		print("E: Invalid input.")
	
# Define main function.
def main():
	# Try to get function name. If it fails, print a error message.
	try:
		cmd_name = func_dict[arg1]
	except KeyError:
		if len(sys.argv) == 1:
			pass
		elif sys.argv[1] == "pi":
			print("PHI is one H of a lot cooler than PI!")
		else:
			print(invalid_cmd)
	else:
		# Check if function requires args.
		# By default, sys.argv[2] will be
		# passed to the function.
		func = eval(cmd_name)
		sig = signature(func)
		paramCount = len(sig.parameters)
		if paramCount == 0:
			prettyprint(func())
		elif paramCount == 1:
			try:
				prettyprint(func(sys.argv[2]))
			except IndexError:
				print(ansi(31))
				print(
					f"E: action {cmd_name} requires input, i.e\n"
					f"psiman {arg1} <input>\n"
					"Type (psiman -h) for more info."
				)
				print(ansi(0))
				
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
	main()
