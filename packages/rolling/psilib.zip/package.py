"""
Contains functions to handle packages
(install, remove, and list packages).
Throws custom exceptions if not sucrssful
(see ./exceptions.py)
"""

# Get global variables and exceptions
# (config.py):
from .config import psicfg_path, script_store, site_packages
from .exceptions import NoInternet, PackageNoExists, PackageNotInRepo
from .exceptions import InvalidJSON, RepoNoExists, RepolistMissing
from .exceptions import VersionErrorMore, VersionErrorSame, SearchNotMatched

# Import modules (local)
from .repo import update
from .utils import isPYUI, get_gist_dl

# Import modules (stdlib)
import os
import glob
import json
import shutil
import requests
from io import BytesIO
from distutils.version import LooseVersion
from zipfile import ZipFile, is_zipfile

def _dumpversion(package, semver):
	"""Dumps name and version to version.json
	"""
	path = psicfg_path + "/json/versions.json"
	# Load json already in versions file
	f = open(path, "r")
	try:
		ver_d = json.load(f)
	except json.decoder.JSONDecodeError:
		# Make new dict
		d = {}
		d.update({package: semver})
		json_str = json.dumps(d, indent=4)
		# Write to file
		with open(path, "w") as f:
			f.write(json_str)
	else:
		# Update existing dict
		ver_d.update({package: semver})
		json_str = json.dumps(ver_d, indent=4)
		# Write to file
		with open(path, "w") as f:
			f.write(json_str)


def _loadversion(pkg):
	"""Retreive version of pkg from
	version.json file
	"""
	path = psicfg_path + "/json/versions.json"
	# Load json already in versions file
	f = open(path, "r")
	try:
		ver_d = json.load(f)
	except json.decoder.JSONDecodeError:
		return None
	else:
		# Try to get version of pkg
		try:
			version = ver_d[pkg]
		except KeyError:
			return None
		else:
			return version


def _chkjsonfile(url):
	"""Detects if package.json file contains
	muitiple packages at once
	"""
	# Checks for <#PACKAGE_NAME> at end of url
	url_p = url.split("#")
	# download and get dict of script
	try:
		pkg_json = requests.get(url)
	except requests.exceptions.ConnectionError:
		raise NoInternet
	pkg_dict = pkg_json.json()
	# If it is a multi-package json file,
	# download and return (the script info)
	# as a dict
	if len(url_p) == 2:
		pkg_name = url_p[-1]
		return_dict = pkg_dict[pkg_name]
		return return_dict
	else:
		# The json file only contains one
		# script, so return the dict.
		return pkg_dict


def _geturlfromjson(script_dict):
	"""Get url from script.json.
	"""
	# Iterate over the list to find
	# latest version.
	pkg_versions = script_dict["releases"]
	# A empty dict to store versions
	ver_d = {}
	for d in pkg_versions:
		try:
			ver_d.update({d["version"]: d["url"]})
		except KeyError:
			# Does not contain a version
			ver_d.update({"N/A": d["url"]})
		else:
			pass
	# Take the last url in the list if there
	# is key [N/A] (no version)
	if "N/A" in d:
		url = pkg_versions[-1]["url"]
		return [url, None]
	else:
		ver_list = sorted(ver_d.keys(), key=LooseVersion)
		# Get url with latest version
		pkg_latest_version = ver_list[-1]
		url = ver_d[pkg_latest_version]
		return [url, pkg_latest_version]

def _index_has_package(package):
	"""Check all downloaded indexes for a
	package, and returns its URL if it exists.
	Otherwise, returns None.
	"""
	# Empty list to record filenames
	file_list = []
	
	# Find all files that are indexes (index.json)
	jsonfile_list = os.listdir(psicfg_path + "/json")
	for filename in jsonfile_list:
		if filename.endswith("index.json"):
			file_list.append(filename)

	# Check if the index has the package
	for index in file_list:
		jsonpath = psicfg_path + "/json/" + index
		with open(jsonpath, 'r') as f:
			json_content = json.load(f)
		try:
			pkg_url = json_content["scripts"][package]["meta_url"]
		except KeyError:
			continue
		else:
			return pkg_url

def _get_all_indexes():
	"""Returns info of packages of all
	indexes downloaded.
	Will clobber duplicate package names.
	"""
	# Empty list to record filenames
	file_list = []
	
	# Empty dict to store the merged index
	script_dict = {}
	
	# Find all files that are indexes (index.json)
	jsonfile_list = os.listdir(psicfg_path + "/json")
	for filename in jsonfile_list:
		if filename.endswith("index.json"):
			file_list.append(filename)
	
	# Iterate over the package list for each index.
	for index_file in file_list:
		path = psicfg_path + "/json/" + index_file
		with open(path, "r") as f:
			index_dict = json.load(f)
		# Get listing of packages under the 
		# 'scripts' key.
		# Update the merged dict with the package name and info.
		# This clobbers any duplicate entries, however.
		script_dict.update(index_dict["scripts"])
	
	# Return the dict
	merged_index = {"scripts": script_dict}
	return merged_index

def installfile(package_name, fileobj_r, pkg_type):
	
	# Get content of fileobj
	if type(fileobj_r) is requests.models.Response:
		fileobj = fileobj_r.content
	else:
		fileobj = fileobj_r.read()

	# Detect if package is .py, .pyui or .zip
	if is_zipfile(BytesIO(fileobj)):
		pkgfile_p = psicfg_path + "/tmp/" + package_name + ".zip"
	elif isPYUI(fileobj):
		pkgfile_p = psicfg_path + "/tmp/" + package_name + ".pyui"
	else:
		# Is python script
		pkgfile_p = psicfg_path + "/tmp/" + package_name + ".py"
	
	# Set install location depending on package type
	if pkg_type == "module":
		script_store_p = site_packages
	else:
		script_store_p = script_store

	# Create temporary file to hold package
	# and write download to temp folder.
	open(pkgfile_p, 'a').close()
	with open(pkgfile_p, "wb") as f:
		f.write(fileobj)

	if is_zipfile(BytesIO(fileobj)):
		# Extract package to script folder
		zf = ZipFile(pkgfile_p, 'r')
		zf.extractall(path=script_store_p)
		# Remove package to save space.
		os.remove(pkgfile_p)
	else:
		path_s = script_store_p + package_name
		# Move .pyui or .py file to scripts
		if pkgfile_p.endswith(".py"):
			os.rename(pkgfile_p, path_s + ".py")
		elif pkgfile_p.endswith(".pyui"):
			os.rename(pkgfile_p, path_s + ".pyui")

	return True

def install(pkg_name):
	"""Installs packages from the main index
	to the script path
	(psi.config.script_store).
	Returns True if sucessful.
	"""
	# Get rid of spaces in package name
	package = pkg_name

	# Try to update index file
	try:
		update()
	except json.JSONDecodeError:
		pass
	except NoInternet:
		pass
	
	# Get json url of package and check if
	# it is valid (i.e, not None).
	pkg_url = _index_has_package(package)
	if pkg_url is None:
		raise PackageNotInRepo
	else:
		pass
	
	try:
		# Get dict from url with _chkjsonfile()
		pkg_infofile = _chkjsonfile(pkg_url)
	except requests.exceptions.ConnectionError:
		raise NoInternet
	else:
		# Cache package json info as file
		with open(psicfg_path + "/json/" + package + ".json", "w") as f:
			json.dump(pkg_infofile, f)
		# Get install location based on
		# the type.
		try:
			pkg_type = pkg_infofile["type"]
		except KeyError:
			pkg_type = "script"
		if pkg_infofile:
			try:
				# Use _geturlfromjson()
				# function to load url
				pkg_list = _geturlfromjson(pkg_infofile)
			except KeyError:
				raise InvalidJSON
			else:
				url = pkg_list[0]
				pkg_latest_version = pkg_list[1]
				# Output package name and version into versions.json
				# if version is higher (skip if version is None)
				while True:
					localVersion = _loadversion(package)
					if localVersion == "N/A" or localVersion is None:
						_dumpversion(package, pkg_latest_version)
						break
					elif localVersion < pkg_latest_version:
						_dumpversion(package, pkg_latest_version)
						break
					elif localVersion == pkg_latest_version:
						raise VersionErrorSame
					elif localVersion > pkg_latest_version:
						raise VersionErrorMore
					break

				# Get package and save it.
				result = get_gist_dl(url)
				# Check if url is a gist
				if result[0]:
					url_g = result[1]
					pkgfile = requests.get(url_g, allow_redirects=True)
				else:
					# Download normally
					pkgfile = requests.get(url, allow_redirects=True)

				if pkgfile:
					installfile(package, pkgfile, pkg_type)
					return True
				elif pkgfile.status_code == 404:
					raise NoInternet
		elif pkg_infofile.status_code == 404:
			raise NoInternet


def remove(pkg_name):
	"""Removes packages in local.
	Returns a 2-list
	([True, [list of files deleted]]) if
	sucessful, Null if there was a error 
	removing an existing package's files.
	"""	
	# Empty dict to return
	return_dict = {}
	
	# Get a list of all files in script_store
	installed_list = os.listdir(script_store)

	# Deletes all files/folders that start
	# with the package name. Very crude.
	for file in installed_list:
		# Match lowercase files
		match = file.startswith(pkg_name.lower()) or file.startswith(pkg_name)
		if match:
			try:
				# Check if it is a file
				if os.path.isfile(script_store + file):
					os.remove(script_store + file)
				else:
					shutil.rmtree(script_store + file)
			except shutil.Error:
				return_dict.update({file: False})
			except OSError:
				return_dict.update({file: False})
			else:
				return_dict.update({file: True})

	# Load versions.json
	with open(psicfg_path + "/json/versions.json", "r") as f:
		rem_d = json.load(f)
	
	# Remove the package version from
	# the loaded dict
	__ = rem_d.pop(pkg_name, None)
	json_str = json.dumps(rem_d, indent=4)
	
	# Save back to versions.json
	with open(psicfg_path + "/json/versions.json", "w") as f:
		f.write(json_str)
	return_dict.update({"removed_package_version": True})

	return return_dict


def desc(pkg_name):
	"""Get infomation metadata on a package.
	Will return a dictionary of metadata on
	the package.
	"""
	# Get rid of spaces in package name
	package = pkg_name.replace(" ", "")
	# Load package URL
	pkg_url = _index_has_package(package)
	if package is None:
		raise PackageNotInRepo
	else:
		pkg_infofile = _chkjsonfile(pkg_url)
		# Save package json info as file
		jsonpath = psicfg_path + "/json/" + package + ".json"
		with open(jsonpath, "w") as f:
			json.dump(pkg_infofile, f)
		return pkg_infofile


def search(terms):
	"""Returns a list of packages depending on search terms
	(i.e, all modules/scripts, packages with
	a certain name, in stable/rolling branch,
	etc.)
	"""
	# Check if search terms match special
	# modifiers
	
	is_type_search = terms == "modules" or terms == "scripts"
	is_branch_search = terms == "rolling" or terms == "stable"
	is_locale_search = terms == "lcl" or terms == "repo"
	
	# Define return list
	return_list = []
	
	# Load index.json
	index_j = _get_all_indexes()
	packages = index_j["scripts"]
		
	# Search for modules/scripts.
	if is_type_search:
		# Iterate over all package metadata in index.
		for pkg_name in packages.keys():
			package_info = packages[pkg_name]
			for key, val in package_info.items():
				if terms == "scripts" and val == "script":
					return_list.append(pkg_name)
				elif terms == "modules" and val == "module":
					return_list.append(pkg_name)
		return(sorted(return_list, key=str.lower))

	elif is_branch_search:
		# Iterate over all package metadata in index.
		for pkg_name in packages.keys():
			package_info = packages[pkg_name]
			for key, val in package_info.items():
				if terms == "stable" and val == "stable":
					return_list.append(pkg_name)
				elif terms == "rolling" and val == "rolling":
					return_list.append(pkg_name)
		return sorted(return_list, key=str.lower)
		
	elif is_locale_search:
		# List all packages in repo
		if terms == "repo":
			for key in packages:
				return_list.append(key)
			# Sort by alphabetical order
			return sorted(return_list, key=str.lower)
		# List all packages in local
		elif terms == "lcl":
			# List all files with extention .py:
			filenme = [f for f in glob.glob(script_store + "*")]
			filenme.sort(key=str.lower)
			for x in filenme:
				if x.endswith(".py"):
					x_r = x.replace(script_store, "")
					x_p = x_r.replace(".py", "")
					return_list.append(x_p)
			return sorted(return_list, key=str.lower)
		
	else:
		# Search for terms within package names
		# If terms is only one letter long,
		# search for all packages starting
		# with that letter
		if len(terms) == 1:
			# Search for both upper and lowercase.
			for pkg_name in packages.keys():
				if pkg_name.startswith(terms.upper()):
					return_list.append(pkg_name)
				elif pkg_name.startswith(terms.lower()):
					return_list.append(pkg_name)
		else:
			for pkg_name in packages.keys():
				if terms in pkg_name:
					return_list.append(pkg_name)

		if len(return_list) == 0:
			raise SearchNotMatched
		else:
			return(return_list)


def upgrade():
	"""(Bulk) upgrades all packages with a
	newer version in the repository.
	Returns a count of upgraded and not upgraded packages.
	"""
	# Iterate though all installed packages
	# (in versions.json).
	notUpgraded_counter = 0
	upgraded_counter = 0
	with open(psicfg_path + "/json/versions.json", "r") as f:
		version_d = json.load(f)
	for pkg in version_d:
		try:
			install(pkg)
		except VersionErrorSame:
			notUpgraded_counter += 1
		else:
			upgraded_counter += 1
	return_dict = {}
	return_dict["upgraded"] = upgraded_counter
	return_dict["notupgraded"] = notUpgraded_counter
	return return_dict
